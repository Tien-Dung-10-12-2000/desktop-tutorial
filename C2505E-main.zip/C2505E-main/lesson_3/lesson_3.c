#include <stdio.h>
#include <math.h>

int main()
{
    // printf("--%d--", sizeof(short));
    // int x = 5;
    // switch (x)
    // {
    // case 5:
    // {
    //     int y = 5;
    //     break;
    // }
    // case 6:
    // {
    //     int y = 6;

    //     break;
    // }
    // default:
    //     break;
    // }

    /*
        Viết chương trình tính tổng 3 số: x, y, z và hiển thị kết quả ra màn hình
        Trong đó x, y, z có thể là kiểu số nguyên hoặc kiểu số thực
    */

    // float x, y, z;
    // // Input x, y, z from console
    // printf("Enter x value: \r\n");
    // scanf("%f", &x);

    // printf("Enter y value: \r\n");
    // scanf("%f", &y);

    // printf("Enter z value: \r\n");
    // scanf("%f", &z);

    // // Print out x, y, z
    // printf("x, y, z = %f, %f, %f;\n", x, y, z);

    // // Print out result;
    // float sum = x + y + z;

    // printf("Sum of (x, y, z) = %f;\n", sum);

    /*
        if/else statement
    */

    // float u = 0;
    // printf("Voltage (u): \n");
    // scanf("%f", &u);

    // if (u > 1) {
    //     printf("The light is ON.\n");
    // }
    // else
    // {
    //     printf("The light is OFF.\n");
    // }

    /*
        1. Viết chương trình kiểm tra nhiệt độ và in ra 'Nóng' nếu lớn hơn 40 độ
        2. Kiểm tra nếu điện áp dưới 3V thì in "Pin yếu"
        3. So sánh hai giá trị cảm biến và in ra giá trị lớn hơn
        4. Nếu cảm biến ánh sáng thấp, in 'Bật đèn'
        5. Kiểm tra một số là âm hay dương để hiện thị cảnh báo.
    */

    return 0;
}
