#include <stdio.h>

int main()
{
    /**
     * Hiển thị số đếm từ 10 đến 1.
     */
    for (int i = 10; i >= 1; i--)
    {
        printf("%d ", i);
    }

    return 0;
}
