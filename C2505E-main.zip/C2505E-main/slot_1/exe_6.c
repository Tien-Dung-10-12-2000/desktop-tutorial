#include <stdio.h>

int main()
{
    /**
     * In ra 10 lần dòng chữ 'Xin chào'.
     */
    for (int i = 0; i < 10; i++)
    {
        printf("Xin chào \n");
    }

    return 0;
}
