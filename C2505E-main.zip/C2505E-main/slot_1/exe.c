#include <stdio.h>

int main()
{
    /* code */
    return 0;
}
