#include <stdio.h>
int main()
{
    printf("Tôi là Nguyễn Đắc Ngọc\n");
    printf("Lớp C2505E\n");
    printf("Trường FPT JETKING\n");
    printf("Tuổi: 29\n");
    return 0;
}
