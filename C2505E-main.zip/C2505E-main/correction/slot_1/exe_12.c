#include <stdio.h>

int main()
{
    /* Use lib */
    return 0;
}
